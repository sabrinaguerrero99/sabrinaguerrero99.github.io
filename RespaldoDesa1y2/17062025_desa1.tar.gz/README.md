# Proyecto práctico para Desarrollo I - HTML y CSS.

## Burger King 

Burger King Corporation, también conocida como BK, es una cadena de restaurantes de comida rápida estadounidense especializada 
en la elaboración de hamburguesas con sede central en Miami, Florida, y subsidiaria de Restaurant Brands International, un holding canadiense con sede en Toronto al que también pertenece Popeyes.

## ¿Cuál es el objetivo de la pagina?

Esta página está construida para la cátedra de Desarrollo I del Instituto ORT, para la entrega final del 1er cuatrimestre de la carrera de Diseño Gráfico Digital.



## ¿Quiénes participan?

* Sabrina Guerrero



###para mas informacion:
https://es.wikipedia.org/wiki/Burger_King
